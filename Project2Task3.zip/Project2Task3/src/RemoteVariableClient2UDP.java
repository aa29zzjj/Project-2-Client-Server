import java.io.IOException;
import java.net.*;
import java.util.Scanner;

//Second Client for screenshot
public class RemoteVariableClient2UDP {
    private static RemoteVariableProxy proxy;

    public static void main(String args[]){
        //client start
        System.out.println("The client is running.");
        Scanner scanner = new Scanner(System.in);

        try {

            // Set the server address and port
            System.out.println("Please enter server port: ");
            int serverPort = scanner.nextInt();
            //use proxy to set up the serverPort and localhost
            proxy = new RemoteVariableProxy(serverPort, "localhost");

            // Loop until user inputs is end (ctrl+z)
            while (true) {
                //selection for user's choice
                //number for user's input value
                //id for user ID
                //clientRequest is decided by user's choice
                int selection;
                int number = 0;
                int id;
                String clientRequest = "";
                //Options for user
                System.out.println("1. Add a value to your sum.");
                System.out.println("2. Subtract a value from your sum.");
                System.out.println("3. Get your sum.");
                System.out.println("4. Exit client");

                selection = scanner.nextInt();
                //user prompt 4, quit the client
                if (selection == 4) {
                    System.out.println("Client side quitting. The remote variable server is still running. ");
                    System.exit(0);
                }
                //1. set the id, request, input number
                if (selection == 1) {
                    System.out.println("Enter value to add: ");
                    number = scanner.nextInt();
                    System.out.println("Enter your ID: ");
                    id = scanner.nextInt();
                    while(id > 999 || id < 0) {
                        System.out.println("Invalid ID. Please try again.");
                        id = scanner.nextInt();
                    }
                    clientRequest = "add";
                } else if (selection == 2) {
                    System.out.println("Enter value to subtract: ");
                    number = scanner.nextInt();
                    System.out.println("Enter your ID: ");
                    id = scanner.nextInt();
                    while(id > 999 || id < 0) {
                        System.out.println("Invalid ID. Please try again.");
                        id = scanner.nextInt();
                    }
                    clientRequest = "subtract";
                } else if (selection == 3) {
                    System.out.println("Enter your ID: ");
                    id = scanner.nextInt();
                    while(id > 999 || id < 0) {
                        System.out.println("Invalid ID. Please try again.");
                        id = scanner.nextInt();
                    }
                    clientRequest = "get";
                }else{
                    //if the selection is not found, re-type the selection
                    System.out.println("Please enter a valid option.");
                    continue;
                }
                //send out the request with id, clientRequest, number set
                int result = proxy.sendRequestToServer(id, clientRequest, number);
                System.out.println("The result is " + result);
            }

        }catch (SocketException e) {System.out.println("Socket Exception: " + e.getMessage());
        }catch (IOException e){System.out.println("IO Exception: " + e.getMessage());
        }finally {if(proxy.getSocket()!= null) proxy.getSocket().close();}
    }


}
