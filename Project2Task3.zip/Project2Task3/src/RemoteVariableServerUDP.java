import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class RemoteVariableServerUDP {
    //create the request handler
    private static RemoteVariableRequestHandler remoteVariableRequestHandler = new RemoteVariableRequestHandler();

    public static void main(String args[]){
        System.out.println("Server started");
        // Initialize a DatagramSocket for UDP communication
        DatagramSocket aSocket = null;
        // Initialize a buffer to store incoming data
        byte[] buffer = new byte[1000];
        Scanner scanner = new Scanner(System.in);

        try{
            //id for client's user ID
            //clientNumber for client's input value
            //clientRequest for client's command
            int id;
            String clientRequest;
            int clientNumber;
            //Prompt the listening port
            System.out.println("Enter the port number to listen on: ");
            int serverPort = scanner.nextInt();
            // Set a socket to port 6789 to listen for packets from client
            aSocket = new DatagramSocket(serverPort);

            // Set a DatagramPacket to receive data from client
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            //Let server keep running
            while(true){
                //wait until client send package to server
                aSocket.receive(request);

                //extract the message from client
                String clientMessage = new String(request.getData(), 0, request.getLength());
                String [] userInputs = clientMessage.split(",");

                //get the info from client
                id = Integer.parseInt(userInputs[0]);
                clientRequest = userInputs[1];
                clientNumber = Integer.parseInt(userInputs[2]);

                //do the required action that send by client
                int result = remoteVariableRequestHandler.serverActionOnRequest(id, clientRequest, clientNumber);
                //client info details
                System.out.println("Server received client's id: "+ id);
                System.out.println("Server received client's request: "+ clientRequest);
                System.out.println("Server received client's number: "+ clientNumber);
                System.out.println("Server response: " + result);

                //set result to be the response
                String response = String.valueOf(result);
                //Another approach would be to only transmit byte arrays containing String data.
                byte[] responseData = response.getBytes();
                //packet the reply and send back to client
                DatagramPacket reply = new DatagramPacket(
                        responseData, responseData.length, request.getAddress(), request.getPort()
                );
                aSocket.send(reply);

            }
        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());
        }finally {if(aSocket != null) aSocket.close();}
    }
}
class RemoteVariableRequestHandler{
    //TreeMap for each user's input
    private Map<Integer, Integer> userNumbersMap = new TreeMap<Integer, Integer>();

    //do the action that request by client
    public int serverActionOnRequest(int id, String clientRequest, int number){
        //check if the user is absent or not. set new user if the users has no record
        userNumbersMap.putIfAbsent(id, 0);
        if(clientRequest.equals("add")){
            //add the value
            userNumbersMap.put(id, userNumbersMap.get(id) + number);
        } else if (clientRequest.equals("subtract")) {
            //subtract the value
            userNumbersMap.put(id, userNumbersMap.get(id) - number);
        } else if (clientRequest.equals("get")) {
            //get the value
            userNumbersMap.get(id);
        }else{
            //Error if the ambiguous variables
            System.out.println("Unknown request");
            return -1;
        }
        return userNumbersMap.get(id);
    }
}