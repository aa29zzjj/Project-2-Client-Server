import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class RemoteVariableClientUDP {
    private static RemoteVariableProxy proxy;

    public static void main(String args[]){
        //client start
        System.out.println("The client is running.");
        Scanner scanner = new Scanner(System.in);

        try {

            // Set the server address and port
            System.out.println("Please enter server port: ");
            int serverPort = scanner.nextInt();
            //use proxy to set up the serverPort and localhost
            proxy = new RemoteVariableProxy(serverPort, "localhost");

            // Loop until user inputs is end (ctrl+z)
            while (true) {
                //selection for user's choice
                //number for user's input value
                //id for user ID
                //clientRequest is decided by user's choice
                int selection;
                int number = 0;
                int id;
                String clientRequest = "";
                //Options for user
                System.out.println("1. Add a value to your sum.");
                System.out.println("2. Subtract a value from your sum.");
                System.out.println("3. Get your sum.");
                System.out.println("4. Exit client");

                selection = scanner.nextInt();
                //user prompt 4, quit the client
                if (selection == 4) {
                    System.out.println("Client side quitting. The remote variable server is still running. ");
                    System.exit(0);
                }
                //1. set the id, request, input number
                if (selection == 1) {
                    System.out.println("Enter value to add: ");
                    number = scanner.nextInt();
                    System.out.println("Enter your ID: ");
                    id = scanner.nextInt();
                    while(id > 999 || id < 0) {
                        System.out.println("Invalid ID. Please try again.");
                        id = scanner.nextInt();
                    }
                    clientRequest = "add";
                } else if (selection == 2) {
                    System.out.println("Enter value to subtract: ");
                    number = scanner.nextInt();
                    System.out.println("Enter your ID: ");
                    id = scanner.nextInt();
                    while(id > 999 || id < 0) {
                        System.out.println("Invalid ID. Please try again.");
                        id = scanner.nextInt();
                    }
                    clientRequest = "subtract";
                } else if (selection == 3) {
                    System.out.println("Enter your ID: ");
                    id = scanner.nextInt();
                    while(id > 999 || id < 0) {
                        System.out.println("Invalid ID. Please try again.");
                        id = scanner.nextInt();
                    }
                    clientRequest = "get";
                }else{
                    //if the selection is not found, re-type the selection
                    System.out.println("Please enter a valid option.");
                    continue;
                }
                //send out the request with id, clientRequest, number set
                int result = proxy.sendRequestToServer(id, clientRequest, number);
                System.out.println("The result is " + result);
            }

        }catch (SocketException e) {System.out.println("Socket Exception: " + e.getMessage());
        }catch (IOException e){System.out.println("IO Exception: " + e.getMessage());
        }finally {if(proxy.getSocket()!= null) proxy.getSocket().close();}
    }


}
//use a proxy design to encapsulate the communication code
class RemoteVariableProxy{
    private int serverPort;
    private InetAddress aHost;
    private DatagramSocket aSocket;

    //constructor to set the serverPort, address of host, and initialize the socket
    public RemoteVariableProxy(int serverPort, String aHost) throws UnknownHostException, SocketException {
        this.serverPort = serverPort;
        this.aHost = InetAddress.getByName(aHost);
        this.aSocket = new DatagramSocket();
    }
    public DatagramSocket getSocket(){
        return aSocket;
    }

    //By using ID, clientRequest(add, subtract, get), and number input to request server
    public int sendRequestToServer(int id, String clientRequest, int number) {
        try{
            //build up message
            String clientRequestValue = id+","+clientRequest+","+number;

            //get the integer byte that provided by client
            byte [] m = clientRequestValue.getBytes();
            //get the request packet and send
            DatagramPacket request = new DatagramPacket(m, m.length, aHost, serverPort);
            aSocket.send(request);

            byte[] buffer = new byte[1000];
            //create a reply packet to receive server's message.
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
            aSocket.receive(reply);
            //return to the integer result of the reply packet
            return Integer.parseInt(new String(reply.getData(), 0 , reply.getLength()));
        }catch (IOException e){
            //Error
            System.out.println(e.getMessage());
            return -1;
        }
    }
}