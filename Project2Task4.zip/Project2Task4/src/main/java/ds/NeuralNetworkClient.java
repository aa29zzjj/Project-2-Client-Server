package ds;
import java.io.IOException;
import java.net.*;
import java.util.*;
import com.google.gson.*;


public class NeuralNetworkClient {
    private static NeuralNetworkProxy proxy;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String args[]){
        //client start
        System.out.println("The client is running.");
        try {
            // Set the server address and port
            System.out.println("Please enter server port: ");
            int serverPort = scanner.nextInt();
            //use proxy to set up the serverPort and localhost
            proxy = new NeuralNetworkProxy(serverPort, "localhost");
            while (true) {
                // let user prompt the choice (get it from NeuralNetwork.java)
                int userSelection = menu();
                //check if user prompt is out of the menu selection
                if(userSelection < 0 || userSelection > 5){
                    System.out.println("Please enter a number between 0 and 5");
                    continue;
                }
                //Create Json request
                JsonObject request = new JsonObject();
                // Options:
                // 0. Display the current truth table.
                // 1. Provide four inputs for the range of the two input truth table and build a new neural network. To test XOR, enter 0  1  1  0.
                // 2. Perform a single training step.
                // 3. Perform n training steps. 10000 is a typical value for n.
                // 4. Test with a pair of inputs.
                // 5. Exit program.
                if(userSelection == 0){
                    //set the request command into request
                    request.addProperty("request", "getCurrentRange");
                } else if (userSelection == 1) {
                    //input the values
                    System.out.println("Enter the four results of a 4 by 2 truth table. Each value should be 0 or 1.");
                    Double val1 = scanner.nextDouble();
                    Double val2 = scanner.nextDouble();
                    Double val3 = scanner.nextDouble();
                    Double val4 = scanner.nextDouble();
                    //set the request command into request
                    request.addProperty("request", "setCurrentRange");
                    request.addProperty("val1", val1);
                    request.addProperty("val2", val2);
                    request.addProperty("val3", val3);
                    request.addProperty("val4", val4);
                }else if(userSelection == 2){
                    //set the request command into request
                    request.addProperty("request", "train");
                    //One-step training
                    request.addProperty("iterations", 1);
                }else if(userSelection == 3){
                    //prompt the number of steps for training
                    System.out.println("Enter the number of training sets.");
                    int steps = scanner.nextInt();
                    while(steps < 0 || steps > 10000){
                        System.out.println("Please enter a number between 0 and 10000");
                        steps = scanner.nextInt();
                    }
                    //set the request command into request
                    request.addProperty("request", "train");
                    request.addProperty("iterations", steps);
                }else if(userSelection == 4){
                    //prompt the double pairs
                    System.out.println("Enter a pair of doubles from a row of the truth table. These are domain values.");
                    double testVal1 = scanner.nextDouble();
                    double testVal2 = scanner.nextDouble();
                    //set the request command into request
                    request.addProperty("request", "test");
                    request.addProperty("val1", testVal1);
                    request.addProperty("val2", testVal2);
                }else if(userSelection == 5){
                    //Quit the client
                    System.out.println("Client quit...");
                    System.exit(0);
                }
                //get the response from server
                String response = proxy.sendJsonRequest(request);
                JsonObject jsonResponse = JsonParser.parseString(response).getAsJsonObject();

                //get the response status by JsonObject
                String status = jsonResponse.get("status").getAsString();
                System.out.println("Server response status: "+ status);
                //Use userSelection to determine which result should client get
                //Once the status is "Ok" reply, get the response
                if(userSelection == 0){
                    if(status.equals("OK")){
                        //get the values from server
                        double val1Result = jsonResponse.get("val1").getAsDouble();
                        double val2Result = jsonResponse.get("val2").getAsDouble();
                        double val3Result = jsonResponse.get("val3").getAsDouble();
                        double val4Result = jsonResponse.get("val4").getAsDouble();
                        //get the response value from Server
                        //Based on the fromula on Neural Network, print out in this way
                        System.out.println("Working with the following truth table");
                        System.out.println("0.0  0.0  " + val1Result);
                        System.out.println("0.0  1.0  " + val2Result);
                        System.out.println("1.0  0.0  " + val3Result);
                        System.out.println("1.0  1.0  " + val4Result);
                    }
                }else if(userSelection == 1){
                    if(status.equals("OK")){
                        //print out if Server successfully complete the process
                        System.out.println("Range is successfully set");
                    }
                }else if(userSelection == 2){
                    if(status.equals("OK")){
                        //get the response value from Server
                        double totalError = jsonResponse.get("val1").getAsDouble();
                        System.out.println("After this step the error is :"+totalError);
                    }
                }else if(userSelection == 3){
                    if(status.equals("OK")){
                        //get the user prompt for training
                        String steps = request.get("iterations").getAsString();
                        //get the response value from Server
                        double totalError = jsonResponse.get("val1").getAsDouble();
                        System.out.println("After "+ steps+" step the error is :"+totalError);
                    }
                }else if(userSelection == 4){
                    if(status.equals("OK")){
                        //get the response value from Server
                        double rangeValue = jsonResponse.get("val1").getAsDouble();
                        System.out.println("The range value is approximately "+ rangeValue);
                    }
                }
            }



        }catch (SocketException e) {System.out.println("Socket Exception: " + e.getMessage());
        }catch (IOException e){System.out.println("IO Exception: " + e.getMessage());
        }finally {if(proxy.getSocket()!= null) proxy.getSocket().close();}
    }

    public static int menu() {
        System.out.println("Using a neural network to learn a truth table.\nMain Menu");
        System.out.println("0. Display the current truth table.");
        System.out.println("1. Provide four inputs for the range of the two input truth table and build a new neural network. To test XOR, enter 0  1  1  0.");
        System.out.println("2. Perform a single training step.");
        System.out.println("3. Perform n training steps. 10000 is a typical value for n.");
        System.out.println("4. Test with a pair of inputs.");
        System.out.println("5. Exit program.");
        int selection = scanner.nextInt();
        return selection;
    }

}
//use a proxy design to encapsulate the communication code
class NeuralNetworkProxy{
    private int serverPort;
    private InetAddress aHost;
    private DatagramSocket aSocket;

    //constructor to set the serverPort, address of host, and initialize the socket
    public NeuralNetworkProxy(int serverPort, String aHost) throws UnknownHostException, SocketException {
        this.serverPort = serverPort;
        this.aHost = InetAddress.getByName(aHost);
        this.aSocket = new DatagramSocket();
    }
    public DatagramSocket getSocket(){
        return aSocket;
    }

    public String sendJsonRequest(JsonObject request) throws IOException {
        String clientRequest = request.toString();
        byte[] requestJsonData = clientRequest.getBytes();
        DatagramPacket reqestJsonPacket = new DatagramPacket(requestJsonData, requestJsonData.length, aHost, serverPort);
        aSocket.send(reqestJsonPacket);

        byte[] responseData = new byte[1000];
        DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length);
        aSocket.receive(responsePacket);

        return new String(responsePacket.getData(), 0, responsePacket.getLength());

    }

}