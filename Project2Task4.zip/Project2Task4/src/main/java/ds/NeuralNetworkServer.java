package ds;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.*;

public class NeuralNetworkServer {
    private static double val1, val2, val3, val4;
    private static double totalError;
    private static NeuralNetwork neuralNetwork;
    private static ArrayList<Double[][]> userTrainingSets;
    private static Random rand = new Random();

    public static void main(String args[]){
        System.out.println("Server started");
        // Initialize a DatagramSocket for UDP communication
        DatagramSocket aSocket = null;
        // Initialize a buffer to store incoming data
        byte[] buffer = new byte[1000];
        Scanner scanner = new Scanner(System.in);

        // Create an initial truth table with all 0's in the range.
        ArrayList<Double[][]> userTrainingSets = new ArrayList<Double[][]>(Arrays.asList(
                new Double[][]{{0.0, 0.0}, {0.0}},
                new Double[][]{{0.0, 1.0}, {0.0}},
                new Double[][]{{1.0, 0.0}, {0.0}},
                new Double[][]{{1.0, 1.0}, {0.0}}
        ));
        //     Create a neural network suitable for working with truth tables.
        //     There will be two inputs, 5 hidden neurons, and 1 output. All weights and biases will be random.
        //     This is the initial neural network on start up.
        NeuralNetwork neuralNetwork = new NeuralNetwork(2, 5, 1, null, null, null, null);

        try{

            System.out.println("Enter the port number to listen on: ");
            int serverPort = scanner.nextInt();
            // Set a socket to port 6789 to listen for packets from client
            aSocket = new DatagramSocket(serverPort);

            // Set a DatagramPacket to receive data from client
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            //Let server keep running
            while(true){
                //Wait until Server receives the request from client
                aSocket.receive(request);
                //Get the client data
                String requestData = new String(request.getData(), 0, request.getLength());
                //Create get the json data from client, processing the request
                JsonObject jsonRequest = JsonParser.parseString(requestData).getAsJsonObject();
                JsonObject jsonResponse = serverActionOnJsonRequest(jsonRequest);
                //get the bytes of response
                byte[] responseData = jsonResponse.toString().getBytes();
                //Packeted, send to the client
                DatagramPacket responsePacket= new DatagramPacket(responseData, responseData.length, request.getAddress(), request.getPort());
                aSocket.send(responsePacket);
            }
        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());}
        finally {if(aSocket != null) aSocket.close();}
    }
    public static JsonObject serverActionOnJsonRequest(JsonObject request){
        //Create response
        JsonObject response = new JsonObject();
        //get the request command
        String requestAction = request.get("request").getAsString();

        if(requestAction.equals("getCurrentRange")){
            //send back to client
            response.addProperty("request", "getCurrentRange");
            response.addProperty("status", "OK");
            response.addProperty("val1", val1);
            response.addProperty("val2", val2);
            response.addProperty("val3", val3);
            response.addProperty("val4", val4);
            //Call when server receive client's request
            System.out.println("Server Response: ");
            System.out.println(response.toString());
        } else if (requestAction.equals("setCurrentRange")) {
            //Get the values provided by client
            val1 = request.get("val1").getAsDouble();
            val2 = request.get("val2").getAsDouble();
            val3 = request.get("val3").getAsDouble();
            val4 = request.get("val4").getAsDouble();
            //Set the userTrainingsSets, provided by NeuralNetwork
            userTrainingSets = new ArrayList<Double[][]>(Arrays.asList(
              new Double[][] {{0.0, 0.0}, {val1}},
              new Double[][] {{0.0, 1.0}, {val2}},
              new Double[][] {{1.0, 0.0}, {val3}},
              new Double[][] {{1.0, 1.0}, {val4}}
            ));
            //Send back to client
            response.addProperty("request", "setCurrentRange");
            response.addProperty("status", "OK");
            response.addProperty("val1", val1);
            response.addProperty("val2", val2);
            response.addProperty("val3", val3);
            response.addProperty("val4", val4);
            System.out.println("Server Response: ");
            System.out.println(response.toString());
            // Build a new neural network with new random weights.
            neuralNetwork = new NeuralNetwork(2, 5, 1, null, null, null, null);

        } else if (requestAction.equals("train")) {
            //code is provided by NeuralNetwork
            //get the number of training sets
            int iterations = request.get("iterations").getAsInt();
            totalError = 0.0;
            for(int i = 0; i < iterations; i++){
                // perform trainng step and display total error.
                int random_choice = rand.nextInt(4);
                // Get the two inputs
                List<Double> userTrainingInputs = Arrays.asList(userTrainingSets.get(random_choice)[0]);
                // Get the one output (in the case of truth tables).
                List<Double> userTrainingOutputs = Arrays.asList(userTrainingSets.get(random_choice)[1]);
                // Show that row to the neural network
                neuralNetwork.train(userTrainingInputs, userTrainingOutputs);
                // Calculate the error
                totalError = neuralNetwork.calculateTotalError(userTrainingSets);
            }
            //Send back to client
            response.addProperty("request", "train");
            response.addProperty("status", "OK");
            response.addProperty("val1", totalError);
            System.out.println("Received Client's request: ");
            System.out.println(response.toString());

        } else if (requestAction.equals("test")) {
            //code is provied by NeuralNetwork
            // test with a pair of inputs.
            double testVal1 = request.get("val1").getAsDouble();
            double testVal2 = request.get("val2").getAsDouble();
            List<Double> testInputs = Arrays.asList(testVal1, testVal2);
            List<Double> testResult = neuralNetwork.feedForward(testInputs);
            response.addProperty("request", "test");
            response.addProperty("status", "OK");
            response.addProperty("val1", testResult.get(0));
            //send response to client
            System.out.println("Server Response: ");
            System.out.println(response.toString());

        }else {
            //if there is an ambiguous request, set the status to ERROR
            response.addProperty("status", "ERROR");
            System.out.println("Server Response: ");
            System.out.println(response.toString());
        }
        return response;
    }
}

