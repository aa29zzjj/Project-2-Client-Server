import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

public class AddingServerUDP {

    private static int sumValue = 0;

    public static void main(String args[]){
        System.out.println("Server started");
        // Initialize a DatagramSocket for UDP communication
        DatagramSocket aSocket = null;
        // Initialize a buffer to store incoming data
        byte[] buffer = new byte[1000];


        Scanner scanner = new Scanner(System.in);
        try{
            //Prompt the listening port
            System.out.println("Enter the port number to listen on: ");
            int serverPort = scanner.nextInt();
            // Set a socket to port 6789 to listen for packets from client
            aSocket = new DatagramSocket(serverPort);

            // Set a DatagramPacket to receive data from client
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            //Let server keep running
            while(true){

                //wait until client send package to server
                aSocket.receive(request);

                //Get the correct number of bytes requested by client
                byte[] requestData = new byte[request.getLength()];
                System.arraycopy(request.getData(), 0, requestData, 0, request.getLength());

                // Convert the client request data to a string
                String requestString = new String(requestData);

                int clientNumber;
                try{
                        clientNumber = Integer.parseInt(requestString);
                } catch (NumberFormatException e) {
                    System.out.println("The input should be Integer. Error message " + requestString);
                    continue;
                }
                System.out.println("Adding: " + clientNumber+ " to "+ sumValue);
                int result = add(clientNumber);
                System.out.println("Returning sum of " + result +" to client");


                String response = String.valueOf(sumValue);
                //Another approach would be to only transmit byte arrays containing String data.
                byte[] responseData = response.getBytes();
                //packet the reply and send back to client
                DatagramPacket reply = new DatagramPacket(
                        responseData, responseData.length, request.getAddress(), request.getPort()
                );
                aSocket.send(reply);

            }
        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());
        }finally {if(aSocket != null) aSocket.close();}
    }
    private static int add(int i) {
        sumValue += i;
        return sumValue;
    }
}
