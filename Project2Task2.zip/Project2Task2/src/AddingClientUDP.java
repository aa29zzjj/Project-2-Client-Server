import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class AddingClientUDP {
    private static int serverPort;
    private static InetAddress aHost;
    private static DatagramSocket aSocket;

    public static void main(String args[]){
        System.out.println("The client is running.");
        // Initialize a DatagramSocket for sending/receiving packets
        aSocket = null;
        Scanner scanner = new Scanner(System.in);
        try {
            // Set the server address and port
            //Set 6789 first
            System.out.println("Please enter server port: ");
            serverPort = scanner.nextInt();

            //hard coded the localhost for host
            aHost = InetAddress.getByName("localhost");
            // Initialize a socket for sending UDP packets
            aSocket = new DatagramSocket();
            String nextLine;
            // Set BufferedReader to read user's input
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));

            // Loop until user inputs is end (ctrl+z)
            while ((nextLine = typed.readLine()) != null) {

                String requestString = nextLine;
                if (requestString.equals("halt!")) {
                    System.out.println("Client side quitting.");
                    System.exit(0);
                }

                try{
                    //get the value from user's prompt
                    int clientValue = Integer.parseInt(nextLine);
                    //call add to request server to sum the value
                    clientValue = add(clientValue);
                    System.out.println("The server returned " + clientValue);

                }catch (NumberFormatException e){
                    System.out.println("Input is not the number. Please enter a valid number");
                }

            }



        }catch (SocketException e) {System.out.println("Socket Exception: " + e.getMessage());
        }catch (IOException e){System.out.println("IO Exception: " + e.getMessage());
        }finally {if(aSocket != null) aSocket.close();}
    }
    public static int add(int i) {
        try{
            //Another approach would be to only transmit byte arrays containing String data.
            //get the integer byte that provided by client
            byte [] m = String.valueOf(i).getBytes();
            //get the request packet and send
            DatagramPacket request = new DatagramPacket(m, m.length, aHost, serverPort);
            aSocket.send(request);

            byte[] buffer = new byte[1000];
            //create a reply packet to receive server's message.
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
            aSocket.receive(reply);
            return Integer.parseInt(new String(reply.getData(), 0 , reply.getLength()));
        }catch (IOException e){
            System.out.println(e.getMessage());
            return -1;
        }
    }

}