import java.net.*; //network package
import java.io.*;  //I/O package
import java.util.Scanner;

public class EchoClientUDP{
    public static void main(String args[]){
        System.out.println("The UDP client is running.");
        // Initialize a DatagramSocket for sending/receiving packets
        DatagramSocket aSocket = null;
        Scanner scanner = new Scanner(System.in);
        try {
            // Set the server address and port
            //Set 6789 first
            System.out.println("Please Enter server port number: ");
            int serverPort = scanner.nextInt();

            //hard coded the localhost for host
            InetAddress aHost = InetAddress.getByName("localhost");
            // Initialize a socket for sending UDP packets
            aSocket = new DatagramSocket();
            String nextLine;
            // Set BufferedReader to read user's input
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("The client is listening on port: "+serverPort);
            // Loop until user inputs is end (ctrl+z)
            while ((nextLine = typed.readLine()) != null) {


                // Set user input to bytes
                byte [] m = nextLine.getBytes();
                // Set a UDP packet to contain the message, sending to the server
                DatagramPacket request = new DatagramPacket(m,  m.length, aHost, serverPort);

                // Send the packet to the server
                aSocket.send(request);
                // Initialize a buffer
                byte[] buffer = new byte[1000];

                //Receive the reply from the server
                DatagramPacket reply = new DatagramPacket(buffer, buffer.length);

                // Wait until receive the response from the server
                aSocket.receive(reply);

                // Get the exact number of bytes received
                byte[] replyData = new byte[reply.getLength()];
                System.arraycopy(reply.getData(), 0, replyData, 0, reply.getLength());

                String replyString = new String(replyData);
                // Print out the reply
                System.out.println("Reply from server: " + replyString);
                //Check if server reply halt! to shut down
                if (replyString.equals("halt!")) {
                    System.out.println("Server received halt!");
                    System.out.println("UDP Client side quitting.");
                    System.exit(0);
                }
            }

        }catch (SocketException e) {System.out.println("Socket Exception: " + e.getMessage());
        }catch (IOException e){System.out.println("IO Exception: " + e.getMessage());
        }finally {if(aSocket != null) aSocket.close();}
    }
}