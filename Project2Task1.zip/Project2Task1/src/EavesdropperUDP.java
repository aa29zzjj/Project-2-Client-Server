import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class EavesdropperUDP {
    public static void main(String[] args) {
        System.out.println("The Eavesdropper is running.");
        // initialize eavesdropperSocket
        DatagramSocket eavesdropperSocket = null;
        Scanner scanner = new Scanner(System.in);

        try {
            // Type the port number for Eavesdropper to listen
            System.out.print("Enter the port number for Eavesdropper to listen on: ");
            int listenPort = scanner.nextInt();
            System.out.print("Enter the masquerading server port: ");
            int serverPort = scanner.nextInt();

            // Set the socket with listenPort
            eavesdropperSocket = new DatagramSocket(listenPort);
            System.out.println("Eavesdropper is listening on port: " + listenPort + " and masquerading as the server on port: " + serverPort);

            byte[] buffer = new byte[1000];

            while (true) {
                DatagramPacket packetFromClient = new DatagramPacket(buffer, buffer.length);
                //Received client's message if client set the same port number
                eavesdropperSocket.receive(packetFromClient);

                //get client's Message
                String receivedMessage = new String(packetFromClient.getData(), 0, packetFromClient.getLength());
                System.out.println("Received message from client: " + receivedMessage);

                // If the message contains "like", replace the first "like" to "dislike"
                if (receivedMessage.contains("like")) {
                    receivedMessage = receivedMessage.replaceFirst("like", "dislike");
                    System.out.println("Modified message: " + receivedMessage);
                }

                // Send the message to real server
                byte[] modifiedData = receivedMessage.getBytes();
                InetAddress serverAddress = InetAddress.getByName("localhost");
                //Send the modified data to the actual server
                DatagramPacket packetToServer = new DatagramPacket(modifiedData, modifiedData.length, serverAddress, serverPort);
                eavesdropperSocket.send(packetToServer);

                // Receive response from server
                DatagramPacket packetFromServer = new DatagramPacket(buffer, buffer.length);
                eavesdropperSocket.receive(packetFromServer);

                //get Response Message
                String serverResponse = new String(packetFromServer.getData(), 0, packetFromServer.getLength());
                System.out.println("Server Response: " + serverResponse);

                // Sent response back to client
                DatagramPacket packetToClient = new DatagramPacket(serverResponse.getBytes(), serverResponse.length(), packetFromClient.getAddress(), packetFromClient.getPort());
                eavesdropperSocket.send(packetToClient);
            }
        } catch (SocketException e) {
            System.out.println("Socket Exception: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            if (eavesdropperSocket != null) eavesdropperSocket.close();
        }
    }
}