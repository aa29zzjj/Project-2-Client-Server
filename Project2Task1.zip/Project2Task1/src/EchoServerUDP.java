import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

public class EchoServerUDP {
    public static void main(String args[]){
        System.out.println("The UDP server is running.");
        // Initialize a DatagramSocket for UDP communication
        DatagramSocket aSocket = null;
        // Initialize a buffer to store incoming data
        byte[] buffer = new byte[1000];

        Scanner scanner = new Scanner(System.in);
        try{
            //Prompt the listening port
            System.out.println("Enter the port number to listen on: ");
            int serverPort = scanner.nextInt();
            // Set a socket to port 6789 to listen for packets from client
            aSocket = new DatagramSocket(serverPort);
            System.out.println("The server is listening on port: "+serverPort);
            // Set a DatagramPacket to receive data from client
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            //Let server keep running
            while(true){

                //wait until client send package to server
                aSocket.receive(request);

                //Get the correct number of bytes received
                byte[] requestData = new byte[request.getLength()];
                System.arraycopy(request.getData(), 0, requestData, 0, request.getLength());
                // Convert the received data to a string
                String requestString = new String(requestData);


                //Check if client sent halt! to shut down
                if (requestString.equals("halt!")) {
                    System.out.println("Server received halt! command.");
                    System.out.println("UDP Server side quitting");
                    //send the reply of halt! to client
                    DatagramPacket reply = new DatagramPacket(
                            "halt!".getBytes(), "halt!".length(), request.getAddress(), request.getPort()
                    );
                    aSocket.send(reply);
                    System.exit(0);
                }

                // Create a reply packet using the received client's data, address, and port
                DatagramPacket reply = new DatagramPacket(
                        requestData, requestData.length, request.getAddress(), request.getPort()
                );

                // Print out the data
                System.out.println("Echoing: "+ requestString);

                // Send the reply packet back to the client
                aSocket.send(reply);
            }
        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());
        }finally {if(aSocket != null) aSocket.close();}
    }
}
